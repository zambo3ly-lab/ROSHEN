import { TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

interface MetricCardProps {
  label: string;
  value: string;
  trend?: 'up' | 'down';
  trendText?: string;
  index: number;
}

export default function MetricCard({ label, value, trend, trendText, index }: MetricCardProps) {
  const [displayValue, setDisplayValue] = useState('0');

  useEffect(() => {
    const isNumber = !isNaN(parseFloat(value.replace(/,/g, '')));
    if (isNumber) {
      const numericValue = parseFloat(value.replace(/,/g, ''));
      const duration = 1500;
      const steps = 60;
      const increment = numericValue / steps;
      let current = 0;

      const timer = setInterval(() => {
        current += increment;
        if (current >= numericValue) {
          setDisplayValue(value);
          clearInterval(timer);
        } else {
          const formatted = Math.floor(current).toLocaleString();
          setDisplayValue(value.includes('/') ? value : formatted);
        }
      }, duration / steps);

      return () => clearInterval(timer);
    } else {
      setDisplayValue(value);
    }
  }, [value]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="bg-roshn-card border border-roshn-border rounded-xl p-6 card-hover"
    >
      <div className="flex items-start justify-between mb-4">
        <span className="text-xs font-semibold text-gray-500 tracking-wider uppercase">{label}</span>
        {trend && (
          <div
            className={`flex items-center gap-1 ${
              trend === 'up' ? 'text-green-500' : 'text-red-500'
            }`}
          >
            {trend === 'up' ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
          </div>
        )}
      </div>
      <div className="font-mono text-4xl font-bold mb-2">{displayValue}</div>
      {trendText && (
        <div className="flex items-center gap-2">
          <span className="text-sm text-roshn-green">{trendText}</span>
        </div>
      )}
    </motion.div>
  );
}
