import { Building2, Flame } from 'lucide-react';
import { motion } from 'framer-motion';

const communities = [
  { rank: 1, name: 'Sadra', location: 'Riyadh', score: 98, streak: true },
  { rank: 2, name: 'Warefa', location: 'Riyadh', score: 95, streak: false },
  { rank: 3, name: 'Al Arous', location: 'Jeddah', score: 92, streak: false },
  { rank: 4, name: 'Marafy', location: 'Jeddah', score: 89, streak: false },
  { rank: 5, name: 'Al Manar', location: 'Makkah', score: 87, streak: false },
  { rank: 6, name: 'Al Falwah', location: 'Ahsa', score: 84, streak: false },
  { rank: 7, name: 'Shams Ar Riyadh', location: 'Riyadh', score: 81, streak: false },
];

export default function CommunityRanking() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4, duration: 0.5 }}
      className="bg-roshn-card border border-roshn-border rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-1">Communities Ranking</h3>
          <p className="text-sm text-gray-500">Performance across all locations</p>
        </div>
        <span className="px-3 py-1 bg-roshn-green/10 text-roshn-green text-xs font-semibold rounded-full">
          2 NEW
        </span>
      </div>

      <div className="space-y-3">
        {communities.map((community, index) => (
          <motion.div
            key={community.rank}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 + index * 0.05, duration: 0.3 }}
            className="flex items-center gap-4 p-4 bg-roshn-dark/50 rounded-lg hover:bg-roshn-dark transition-colors"
          >
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                community.rank === 1
                  ? 'bg-gradient-to-br from-yellow-400 to-yellow-600 text-black'
                  : community.rank === 2
                  ? 'bg-gradient-to-br from-gray-300 to-gray-500 text-black'
                  : community.rank === 3
                  ? 'bg-gradient-to-br from-orange-400 to-orange-600 text-black'
                  : 'bg-roshn-border text-gray-400'
              }`}
            >
              {community.rank}
            </div>

            <div className="w-10 h-10 bg-gradient-to-br from-roshn-green/20 to-roshn-blue/20 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-roshn-green" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="font-semibold truncate">{community.name}</p>
                {community.streak && (
                  <div className="flex items-center gap-1 px-2 py-0.5 bg-orange-500/10 text-orange-500 rounded-full">
                    <Flame className="w-3 h-3" />
                    <span className="text-xs font-medium">2 weeks</span>
                  </div>
                )}
              </div>
              <p className="text-xs text-gray-500">{community.location}</p>
            </div>

            <div className="text-right">
              <div className="font-mono text-xl font-bold text-roshn-green">
                {community.score}
              </div>
              <div className="text-xs text-gray-500">points</div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
