import { Zap, CheckCircle2, AlertTriangle, Lightbulb, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

const notifications = [
  {
    id: 1,
    type: 'info',
    category: 'ENERGY OPTIMIZATION',
    title: 'Peak Demand Managed',
    description: 'Peak demand managed successfully. Saved 2.3M kWh across all communities.',
    time: new Date(Date.now() - 2 * 60 * 60 * 1000),
    icon: Zap,
  },
  {
    id: 2,
    type: 'success',
    category: 'MAINTENANCE',
    title: 'Maintenance Completed',
    description: 'Predictive maintenance in Sadra Zone B completed. Zero downtime achieved.',
    time: new Date(Date.now() - 5 * 60 * 60 * 1000),
    icon: CheckCircle2,
  },
  {
    id: 3,
    type: 'warning',
    category: 'PARKING ALERT',
    title: 'Capacity Warning',
    description: 'Warefa parking approaching 90% capacity. Overflow areas automatically opened.',
    time: new Date(Date.now() - 8 * 60 * 60 * 1000),
    icon: AlertTriangle,
  },
  {
    id: 4,
    type: 'info',
    category: 'AI INSIGHT',
    title: 'Community Event Recommended',
    description: 'Community event recommended for Al Arous based on resident patterns analysis.',
    time: new Date(Date.now() - 24 * 60 * 60 * 1000),
    icon: Lightbulb,
  },
];

const typeColors = {
  success: 'from-green-500/20 to-green-500/5 border-green-500/30 text-green-500',
  info: 'from-roshn-blue/20 to-roshn-blue/5 border-roshn-blue/30 text-roshn-blue',
  warning: 'from-orange-500/20 to-orange-500/5 border-orange-500/30 text-orange-500',
  alert: 'from-red-500/20 to-red-500/5 border-red-500/30 text-red-500',
};

export default function NotificationsSidebar() {
  return (
    <aside className="fixed right-0 top-0 h-screen w-80 bg-roshn-card border-l border-roshn-border flex flex-col">
      <div className="p-6 border-b border-roshn-border">
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-lg font-semibold">Notifications</h2>
          <button className="text-xs text-roshn-green hover:text-roshn-green/80 transition-colors font-medium">
            CLEAR ALL
          </button>
        </div>
        <p className="text-xs text-gray-500">Real-time system updates</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <AnimatePresence>
          {notifications.map((notification, index) => {
            const Icon = notification.icon;
            return (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: index * 0.1, duration: 0.3 }}
                className={`bg-gradient-to-br ${
                  typeColors[notification.type as keyof typeof typeColors]
                } border rounded-xl p-4 hover:scale-[1.02] transition-transform cursor-pointer group relative`}
              >
                <button className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <X className="w-3 h-3" />
                </button>

                <div className="flex items-start gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-black/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs font-semibold tracking-wider uppercase block mb-1">
                      {notification.category}
                    </span>
                    <h4 className="text-sm font-semibold text-white mb-1">
                      {notification.title}
                    </h4>
                  </div>
                </div>

                <p className="text-xs text-gray-300 leading-relaxed mb-2 ml-11">
                  {notification.description}
                </p>

                <div className="text-xs text-gray-400 ml-11">
                  {formatDistanceToNow(notification.time, { addSuffix: true })}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      <div className="p-4 border-t border-roshn-border">
        <button className="w-full py-3 bg-roshn-dark hover:bg-roshn-border rounded-lg text-sm font-medium transition-colors">
          SHOW ALL (4)
        </button>
      </div>
    </aside>
  );
}
