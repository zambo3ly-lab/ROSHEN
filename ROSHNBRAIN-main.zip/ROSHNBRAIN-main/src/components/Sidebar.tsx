import { Home, Building2, BarChart3, TrendingUp, ShoppingBag, Users, Settings, User } from 'lucide-react';

const navItems = [
  { icon: Home, label: 'Overview', active: true },
  { icon: Building2, label: 'Communities', badge: '7' },
  { icon: BarChart3, label: 'Analytics' },
  { icon: TrendingUp, label: 'Predictions' },
  { icon: ShoppingBag, label: 'Marketplace' },
  { icon: Users, label: 'Residents' },
  { icon: Settings, label: 'Settings' },
];

export default function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 h-screen w-60 bg-roshn-card border-r border-roshn-border flex flex-col">
      <div className="p-6 border-b border-roshn-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-roshn-green to-roshn-blue rounded-xl flex items-center justify-center">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">ROSHN Brain</h1>
            <p className="text-xs text-gray-500">Smart City OS</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                item.active
                  ? 'bg-roshn-green/10 text-roshn-green'
                  : 'text-gray-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-sm font-medium">{item.label}</span>
              {item.badge && (
                <span className="ml-auto text-xs bg-roshn-green/20 text-roshn-green px-2 py-0.5 rounded-full">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-roshn-border">
        <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer">
          <div className="w-10 h-10 bg-gradient-to-br from-roshn-blue to-roshn-green rounded-full flex items-center justify-center">
            <User className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">Sarah Al-Rashid</p>
            <p className="text-xs text-gray-500 truncate">System Administrator</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
