import { motion } from 'framer-motion';
import { Cpu, Radio, Bell, CheckCircle2 } from 'lucide-react';

export default function SystemStatus() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4, duration: 0.5 }}
      className="bg-roshn-card border border-roshn-border rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-1">System Status</h3>
          <p className="text-sm text-gray-500">Infrastructure health monitoring</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 text-green-500 rounded-full">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-xs font-semibold">ONLINE</span>
        </div>
      </div>

      <div className="mb-8">
        <div className="w-full h-48 bg-roshn-dark/50 rounded-xl flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-roshn-green/5 to-roshn-blue/5" />
          <motion.div
            animate={{
              scale: [1, 1.05, 1],
              rotate: [0, 5, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative"
          >
            <div className="w-32 h-32 bg-gradient-to-br from-roshn-green/20 to-roshn-blue/20 rounded-2xl flex items-center justify-center backdrop-blur-sm border border-roshn-border">
              <Cpu className="w-16 h-16 text-roshn-green" strokeWidth={1.5} />
            </div>
          </motion.div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-roshn-dark/50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <p className="text-sm font-medium">AI Models</p>
              <p className="text-xs text-gray-500">Machine learning systems</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-mono text-lg font-bold text-green-500">24/24</p>
            <p className="text-xs text-gray-500">Running</p>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 bg-roshn-dark/50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-roshn-blue/10 rounded-lg flex items-center justify-center">
              <Radio className="w-5 h-5 text-roshn-blue" />
            </div>
            <div>
              <p className="text-sm font-medium">Sensors Online</p>
              <p className="text-xs text-gray-500">IoT network status</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-mono text-lg font-bold text-roshn-blue">99.9%</p>
            <p className="text-xs text-gray-500">Active</p>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 bg-roshn-dark/50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500/10 rounded-lg flex items-center justify-center">
              <Bell className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <p className="text-sm font-medium">Active Alerts</p>
              <p className="text-xs text-gray-500">Monitoring streams</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-mono text-lg font-bold text-orange-500">7,284</p>
            <p className="text-xs text-gray-500">Tracking</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
