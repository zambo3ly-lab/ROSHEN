import { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { motion } from 'framer-motion';

const generateData = (period: 'week' | 'month' | 'year') => {
  if (period === 'week') {
    return [
      { date: 'Mon', energy: 45, water: 32, parking: 78 },
      { date: 'Tue', energy: 52, water: 38, parking: 82 },
      { date: 'Wed', energy: 48, water: 35, parking: 75 },
      { date: 'Thu', energy: 61, water: 42, parking: 88 },
      { date: 'Fri', energy: 55, water: 40, parking: 92 },
      { date: 'Sat', energy: 67, water: 48, parking: 85 },
      { date: 'Sun', energy: 58, water: 43, parking: 79 },
    ];
  } else if (period === 'month') {
    return [
      { date: 'Week 1', energy: 180, water: 145, parking: 320 },
      { date: 'Week 2', energy: 205, water: 168, parking: 350 },
      { date: 'Week 3', energy: 192, water: 155, parking: 335 },
      { date: 'Week 4', energy: 220, water: 180, parking: 365 },
    ];
  } else {
    return [
      { date: 'Jan', energy: 720, water: 580, parking: 1280 },
      { date: 'Feb', energy: 680, water: 550, parking: 1200 },
      { date: 'Mar', energy: 750, water: 610, parking: 1320 },
      { date: 'Apr', energy: 790, water: 640, parking: 1380 },
      { date: 'May', energy: 820, water: 670, parking: 1420 },
      { date: 'Jun', energy: 880, water: 720, parking: 1520 },
      { date: 'Jul', energy: 920, water: 750, parking: 1580 },
      { date: 'Aug', energy: 890, water: 730, parking: 1540 },
      { date: 'Sep', energy: 850, water: 690, parking: 1480 },
      { date: 'Oct', energy: 810, water: 660, parking: 1400 },
      { date: 'Nov', energy: 780, water: 630, parking: 1360 },
      { date: 'Dec', energy: 760, water: 620, parking: 1340 },
    ];
  }
};

export default function Chart() {
  const [period, setPeriod] = useState<'week' | 'month' | 'year'>('week');
  const data = generateData(period);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.5 }}
      className="bg-roshn-card border border-roshn-border rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold mb-1">Resource Consumption</h3>
          <p className="text-sm text-gray-500">Real-time monitoring across all communities</p>
        </div>
        <div className="flex gap-2 bg-roshn-dark rounded-lg p-1">
          {(['week', 'month', 'year'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-4 py-2 rounded-md text-xs font-medium uppercase tracking-wider transition-all duration-200 ${
                period === p
                  ? 'bg-roshn-green text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={320}>
        <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorEnergy" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#00CC88" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#00CC88" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="colorWater" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#0066FF" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#0066FF" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="colorParking" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#FF9500" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#FF9500" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#252525" />
          <XAxis dataKey="date" stroke="#666" style={{ fontSize: '12px' }} />
          <YAxis stroke="#666" style={{ fontSize: '12px' }} />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1A1A1A',
              border: '1px solid #252525',
              borderRadius: '8px',
              fontSize: '12px',
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: '12px', paddingTop: '20px' }}
            iconType="circle"
          />
          <Area
            type="monotone"
            dataKey="energy"
            stroke="#00CC88"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorEnergy)"
            name="Energy (kWh)"
          />
          <Area
            type="monotone"
            dataKey="water"
            stroke="#0066FF"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorWater)"
            name="Water (m³)"
          />
          <Area
            type="monotone"
            dataKey="parking"
            stroke="#FF9500"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorParking)"
            name="Parking (%)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
