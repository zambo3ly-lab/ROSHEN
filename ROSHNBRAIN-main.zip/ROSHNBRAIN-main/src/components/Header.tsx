import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { Clock } from 'lucide-react';

export default function Header() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [lastUpdated] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="mb-6 md:mb-8">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-2">OVERVIEW</h1>
          <div className="flex items-center gap-2 text-xs md:text-sm text-gray-500">
            <Clock className="w-3 h-3 md:w-4 md:h-4" />
            <span>Last updated: {format(lastUpdated, 'HH:mm:ss')}</span>
          </div>
        </div>
        <div className="text-left md:text-right">
          <div className="font-mono text-xl md:text-2xl font-bold text-roshn-green">
            {format(currentTime, 'HH:mm:ss')}
          </div>
          <div className="text-xs md:text-sm text-gray-500">
            {format(currentTime, 'EEEE, MMMM d, yyyy')}
          </div>
        </div>
      </div>
    </div>
  );
}
