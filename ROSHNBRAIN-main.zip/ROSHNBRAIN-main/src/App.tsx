import { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import MetricCard from './components/MetricCard';
import Chart from './components/Chart';
import CommunityRanking from './components/CommunityRanking';
import SystemStatus from './components/SystemStatus';
import NotificationsSidebar from './components/NotificationsSidebar';
import MobileNav from './components/MobileNav';
import MobileNotifications from './components/MobileNotifications';
import LoadingScreen from './components/LoadingScreen';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <AnimatePresence mode="wait">
        {isLoading && <LoadingScreen />}
      </AnimatePresence>

      <div className="min-h-screen bg-roshn-dark">
        <div className="hidden lg:block">
          <Sidebar />
        </div>

        <MobileNav />

        <main className="lg:ml-60 xl:mr-80 p-4 md:p-6 lg:p-8 min-h-screen pt-20 lg:pt-8">
          <Header />

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
            <MetricCard
              label="COMMUNITY PULSE"
              value="98/100"
              trend="up"
              trendText="↑ Excellent"
              index={0}
            />
            <MetricCard
              label="OCCUPIED UNITS"
              value="385,247"
              trendText="/ 400,000 total"
              index={1}
            />
            <MetricCard
              label="OPERATIONAL EFFICIENCY"
              value="94.2%"
              trend="up"
              trendText="↑ 3 weeks streak"
              index={2}
            />
          </div>

          <div className="mb-6 md:mb-8">
            <Chart />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-20 lg:mb-0">
            <CommunityRanking />
            <SystemStatus />
          </div>
        </main>

        <div className="hidden xl:block">
          <NotificationsSidebar />
        </div>

        <MobileNotifications />
      </div>
    </>
  );
}

export default App;
